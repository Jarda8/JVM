package knapsackdynamic;

/**
 *
 * @author Jaroslav Ševčík
 */
public class Knapsack {

    
    int[] solution;
    int n;
    int capacity;
    int[][] table;
    Stuff[] allStuff;
    int sumOfCosts;

    int bestCost;
    int solutionWeight;

    public Knapsack(int n, int capacity, Stuff[] allStuff) {
        solution = new int[n];
        this.sumOfCosts = 0;
        this.n = n;
        this.capacity = capacity;
        this.allStuff = allStuff;
        for (int i = 0; i < n; i++) {
//            solution[i] = 0;
            sumOfCosts += allStuff[i].cost;
        }
        bestCost = 0;
        solutionWeight = 0;
        table = new int[n + 1][sumOfCosts + 1];
    }

    public int[] solve() {
        int i = sumOfCosts;
        int cost;
        while (i > 0 && solveRecur(n, i) > capacity) {
            i--;
        }
        cost = i;
        for (int j = n - 1; j >= 0; j--) {
            if (table[j][cost] != table[j + 1][cost]) {
                solution[j] = 1;
                cost -= allStuff[j].cost;
            }
        }
        return solution;
    }

    private int solveRecur(int item, int cost) {
        int weight1;
        int weight2;

        if (cost == 0) {
            return 0;
        } else if (cost < 0) {
            return 10000;
        } else if (table[item][cost] == 0) {
            if (item == 0) {
                table[0][cost] = 10000;
                return 10000;
            } else {
                weight1 = solveRecur(item - 1, cost);
                weight2 = solveRecur(item - 1, cost - allStuff[item - 1].cost);
                if (weight2 != 10000) {
                    weight2 += allStuff[item - 1].weight;
                }
                table[item][cost] = weight1 < weight2 ? weight1 : weight2;
                return table[item][cost];
            }
        } else {
            return table[item][cost];
        }
    }

}
