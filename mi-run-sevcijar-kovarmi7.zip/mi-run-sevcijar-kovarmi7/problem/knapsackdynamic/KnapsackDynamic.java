package knapsackdynamic;

import initclasses.File;
import java.io.IOException;

/**
 *
 * @author Jaroslav Ševčík
 */
public class KnapsackDynamic {

    public static void main(String[] args) throws IOException {
//        Path filePath = Paths.get(args[0]);
//        Scanner scanner;

        if (args.length < 2) {
            System.out.println("Špatný počet argumentů! Musíte zadat název vstupního a výstupního souboru.");
            return;
        }

        File inputFile = new File(args[0]);
        File outputFile = new File(args[1]);
        int n;
        int capacity;
        Stuff[] allStuff;
        int[] solution;
        int[] input;
//        int bestCost = 0;

//            scanner = new Scanner(filePath);
//            while (scanner.hasNext()) {
        input = inputFile.readInts(1);
        n = input[0];
        input = inputFile.readInts(n * 2 + 2);
        capacity = input[1];
        allStuff = new Stuff[n];

        int idx = 2;
        for (int i = 0; i < n; i++) {
            allStuff[i] = new Stuff(input[idx], input[idx + 1]);
            idx += 2;
        }
//        allStuff[0] = new Stuff(18, 114);
//        allStuff[1] = new Stuff(42, 136);
//        allStuff[2] = new Stuff(88, 192);
//        allStuff[3] = new Stuff(3, 223);

        Knapsack knapsack = new Knapsack(n, capacity, allStuff);

        solution = knapsack.solve();
        
//        for(int i = 0; i < solution.length; i++) {
//            if(solution[i] == 1) {
//                bestCost += allStuff[i].cost;
//            }
//        }
        
        outputFile.writeInts(solution);

//            System.out.print(id + " " + n + " " + bestCost);
//            
//            for (int i = 0; i < n; i++) {
//                System.out.print(" " + solution[i]);
//            }
//            System.out.println("");
//            }
//            scanner.close();
    }
}
