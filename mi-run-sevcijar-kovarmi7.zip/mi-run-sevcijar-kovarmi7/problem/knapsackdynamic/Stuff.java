package knapsackdynamic;

/**
 *
 * @author Jaroslav Ševčík
 */
public class Stuff {

    public int weight;
    public int cost;

    public Stuff(int weight, int cost) {
        this.weight = weight;
        this.cost = cost;
    }
}
