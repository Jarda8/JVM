//package jvm.values;
//
///**
// *
// * @author Jaroslav Ševčík
// */
////Tohle je možná zbytečný.
//public class ReturnAddressValue extends Value{
//    /*The returnAddress type is used by the Java Virtual Machine's jsr, ret, and jsr_w instructions.
//    The values of the returnAddress type are pointers to the opcodes of Java Virtual Machine instructions. (ze specifikace)
//    Index do bajtkódu?*/
//    private int value;
//
//    public ReturnAddressValue(int value) {
//        this.value = value;
//    }
//
//    public int getValue() {
//        return value;
//    }
//
//    public void setValue(int value) {
//        this.value = value;
//    }
//    
//}
