package initclasses;

public class Object {

}
